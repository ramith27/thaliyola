# Deep notes
